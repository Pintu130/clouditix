import React from "react";

const PreferanceModel = () => {
  return <div>hii</div>;
};

export default PreferanceModel;
